
const phone='967777654085';
const products=[
{name:'أرز',price:4500},
{name:'سكر',price:3500},
{name:'زيت',price:7000},
{name:'حليب',price:2500},
{name:'بسكويت',price:500},
{name:'مياه',price:300}
];

let cart=[];

function render(items){
document.getElementById('products').innerHTML=items.map(p=>`
<div class="card">
<h3>${p.name}</h3>
<p>${p.price} ريال يمني</p>
<button onclick="add('${p.name}',${p.price})">إضافة للسلة</button>
</div>`).join('');
}

function add(name,price){
cart.push({name,price});
document.getElementById('cart').innerHTML=cart.map(i=>`<li>${i.name} - ${i.price}</li>`).join('');
}

function sendWhatsApp(){
let txt='طلب جديد:%0A'+cart.map(i=>i.name+' - '+i.price).join('%0A');
window.open('https://wa.me/'+phone+'?text='+txt,'_blank');
}

document.getElementById('search').addEventListener('input',e=>{
const q=e.target.value;
render(products.filter(p=>p.name.includes(q)));
});

render(products);
